﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LibraryManagement.Controllers
{
    public class AdminrolesController : Controller
    {
        // GET: Adminroles
        public ActionResult Index()
        {
            return View();
        }
    }
}