﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibraryManagement.Models;

namespace LibraryManagement.Controllers
{

    public class ReturnBooksController : Controller
    {
        private LibraryEntities1 db = new LibraryEntities1();

        // GET: ReturnBooks
        public ActionResult Index()
        {

            var returnBooks = db.ReturnBooks.Include(r => r.Book).Include(r => r.User);
            return View(returnBooks.ToList());
        }
        public ActionResult Index2()
        {

            var returnBooks = db.ReturnBooks.Include(r => r.Book).Include(r => r.User);
            return View(returnBooks.ToList());
        }
        [HttpGet ]
        public ActionResult Returnbookreports()
        {
            int a = Convert.ToInt32(Session["UserId"]);
           
            var query = from emp in db.ReturnBooks.ToList()
                        where emp.UserId  == a select emp;

            return View(query);
        }

        public ActionResult LibrarinReport(string name)
        {
            name = "Librarian";
            var query = from emp in db.Users.ToList()
                        where emp.Roles == name
                        select emp;

            return View(query);
            //return View(db.Users.ToList());
        }
        //public ActionResult Returnbookreports()
        //{
        //    int a = Convert.ToInt32(Session["UserId"]);

        //    //var returnBooks = db.ReturnBooks.Include(r => r.Book).Include(r => r.User);
        //    var re= from retrn in db.Users.ToList()
        //            where retrn.UserId      == a
        //            select retrn ;

        //    return View(re);
        //}
        //// GET: ReturnBooks/Details/5

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReturnBook returnBook = db.ReturnBooks.Find(id);
            if (returnBook == null)
            {
                return HttpNotFound();
            }
            return View(returnBook);
        }

        // GET: ReturnBooks/Create
        public ActionResult Create()
        {
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username");
            return View();
        }

        // POST: ReturnBooks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReturnId,Issuedate,Returndate,BookId,UserId,Penalty")] ReturnBook returnBook)
        {
            string a = Convert.ToString(Session["Roles"]);


            if (ModelState.IsValid)
            {
                db.ReturnBooks.Add(returnBook);
                db.SaveChanges();

                if(a=="Employee")
                return RedirectToAction("Returnbookreports");
                else
                    return RedirectToAction("Index");


            }

            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", returnBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", returnBook.UserId);
            return View(returnBook);
        }

        // GET: ReturnBooks/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReturnBook returnBook = db.ReturnBooks.Find(id);
            if (returnBook == null)
            {
                return HttpNotFound();
            }
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", returnBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", returnBook.UserId);
            return View(returnBook);
        }

        // POST: ReturnBooks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReturnId,Issuedate,Returndate,BookId,UserId,Penalty")] ReturnBook returnBook)
        {
            if (ModelState.IsValid)
            {
                db.Entry(returnBook).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Returnbookreports");
            }
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", returnBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", returnBook.UserId);
            return View(returnBook);
        }

        // GET: ReturnBooks/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReturnBook returnBook = db.ReturnBooks.Find(id);
            if (returnBook == null)
            {
                return HttpNotFound();
            }
            return View(returnBook);
        }

        // POST: ReturnBooks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ReturnBook returnBook = db.ReturnBooks.Find(id);
            db.ReturnBooks.Remove(returnBook);
            db.SaveChanges();
            return RedirectToAction("Returnbookreports");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
