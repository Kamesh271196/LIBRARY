﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibraryManagement.Models;

namespace LibraryManagement.Controllers
{
   


    public class UsersController : Controller
    {
        private LibraryEntities1 db = new LibraryEntities1();

        // GET: Users
        //[Authorize(Roles = "Employee")]

        public ActionResult Index()
        {
            //var obj = db.Users.Where(a => a.Username.Equals(objUser.Username) from a).FirstOrDefault();

            return View(db.Users.ToList());

        }
        //public ActionResult EmployeeDetails()
        //{
        //    var user = db.Get

        //}

        // GET: Users/Details/5

        //public ActionResult EmployeeDetails()
        //{
        //    return View(db.Users.ToList());
        //}
        ////GET:ResetPassword
        //[HttpPost]
        // GET: Products
        //[HttpGet ]
        public ActionResult EmployeeReport(string name)
        {
            name = "Employee";
            var query = from emp in db.Users.ToList()
                        where emp.Roles == name
                        select emp;

           

            return View(query);
            //return View(db.Users.ToList());
        }

        public ActionResult LibrarinReport(string name)
        {
            name = "Librarian";
            var query = from emp in db.Users.ToList()
                        where emp.Roles == name
                        select emp;

            return View(query);
            //return View(db.Users.ToList());
        }
        //public ActionResult EmployeeReport(string name)
        //{
        //    name = "Employee";
        //    var query = from emp in db.Users .ToList()
        //                where emp.Roles == name
        //                select emp;

        //    return View(query);
        //}
        [HttpGet]
        public ActionResult EmployeeDetails()
        {
            int a = Convert.ToInt32(Session["UserId"]);

            //var b = from up in db.Users .ToList()
            //             where up.UserId  == a
            //             select up;

            User user = db.Users.Find(a);

            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        public ActionResult Details(int ?id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: Users/Create
        public ActionResult Create()
        {

            return View();
        }

       // POST: Users/Create
        //To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "UserId,Username,Name,Password,EmailId,DOB,PhoneNumber,City,Designation,Roles,Gender")] User user)
        {
           
            
                    if (ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            
            //catch (RetryLimitExceededException /* dex */)
            //{
            //    //Log the error (uncomment dex variable name and add a line here to write a log.)
            //    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists, see your system administrator.");
            //}
            //PopulaterolesDropDownList(user.Roles);
          return View(user);
        }

        // GET: Users/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "UserId,Username,Name,Password,EmailId,DOB,PhoneNumber,City,Designation,Roles,Gender")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("EmployeeDetails");
            }
            return View(user);
        }

        // GET: Users/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
        //private void PopulaterolesDropDownList(object selectedRoles = null)
        //{
        //    var rolesQuery = from d in db.Users 
        //                           orderby d.Username
        //                           select d;
        //    ViewBag.DepartmentID = new SelectList(rolesQuery, "UserId", "Username", selectedRoles);
        //}
    }
}
