﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using LibraryManagement.Models;

namespace LibraryManagement.Controllers
{
    public class IssueBooks2Controller : Controller
    {
        private LibraryEntities1 db = new LibraryEntities1();

        // GET: IssueBooks2
        public ActionResult Index()
        {
            var issueBooks = db.IssueBooks.Include(i => i.Book).Include(i => i.User);
            return View(issueBooks.ToList());
        }

        // GET: IssueBooks2/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueBook issueBook = db.IssueBooks.Find(id);
            if (issueBook == null)
            {
                return HttpNotFound();
            }
            return View(issueBook);
        }
        [HttpGet]
        public ActionResult Issuebookreports()
        {
            int a = Convert.ToInt32(Session["UserId"]);

            var query = from emp in db.IssueBooks.ToList()
                        where emp.UserId == a
                        select emp;

            return View(query);
        }

        // GET: IssueBooks2/Create
        public ActionResult Create()
        {
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName");
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username");
            return View();
        }

        // POST: IssueBooks2/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IssueId,days,Issuedate,Returndate,BookId,UserId,Status,EmailId")] IssueBook issueBook)
        {
            string a = Convert.ToString(Session["Roles"]);

            if (ModelState.IsValid)
            {
                db.IssueBooks.Add(issueBook);
                db.SaveChanges();

                if (a == "Employee")
                    return RedirectToAction("Issuebookreports");
                else
                    return RedirectToAction("Index");
                //return RedirectToAction("Issuebookreports");
            }

            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", issueBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", issueBook.UserId);
            return View(issueBook);
        }

        // GET: IssueBooks2/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueBook issueBook = db.IssueBooks.Find(id);
            if (issueBook == null)
            {
                return HttpNotFound();
            }
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", issueBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", issueBook.UserId);
            return View(issueBook);
        }

        // POST: IssueBooks2/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IssueId,days,Issuedate,Returndate,BookId,UserId,Status,EmailId")] IssueBook issueBook)
        {
            if (ModelState.IsValid)
            {
                db.Entry(issueBook).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Issuebookreports");
            }
            ViewBag.BookId = new SelectList(db.Books, "BookID", "BookName", issueBook.BookId);
            ViewBag.UserId = new SelectList(db.Users, "UserId", "Username", issueBook.UserId);
            return View(issueBook);
        }

        // GET: IssueBooks2/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            IssueBook issueBook = db.IssueBooks.Find(id);
            if (issueBook == null)
            {
                return HttpNotFound();
            }
            return View(issueBook);
        }

        // POST: IssueBooks2/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            IssueBook issueBook = db.IssueBooks.Find(id);
            db.IssueBooks.Remove(issueBook);
            db.SaveChanges();
            return RedirectToAction("Issuebookreports");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
