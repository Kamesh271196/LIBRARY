﻿using LibraryManagement.Models;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using LibraryManagement.Models.Extended;

namespace LibraryManagement.Controllers
{
    public class HomeController : Controller
    {
        private LibraryEntities1 db = new LibraryEntities1();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult ResetPassword()
        {
            return View();
        }
        //GET:ResetPassword
        [HttpPost ]
        public ActionResult ResetPassword(Models.User obj)
        {
            int a = Convert.ToInt32(Session["UserId"]);

            Models.User u = db.Users.Find(a);
            var b = db.Users.Where(e => e.Username.Equals(obj.Username) && e.EmailId.Equals(obj.EmailId)).FirstOrDefault();
           if(b!=null)
            {
                b.Password = obj.Password;
                db.Entry(b).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                ViewBag.Message = "your password is modified successfully";
            }
            return RedirectToAction ("Login","Home");

        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Login(Login objUser)
        {    

            if(!ModelState.IsValid)
            {
                return View(objUser);
            }
            else
            {
                using (LibraryEntities1 db = new LibraryEntities1())
                {
                    var obj = db.Users.Where(a => a.Username.Equals(objUser.Username) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        FormsAuthentication.SetAuthCookie(objUser.EmailId , false);

                        //Session["UserID"] = obj.UserID.ToString();
                        //Session["UserName"] = obj.UserName.ToString();

                        Session["UserID"] = obj.UserId.ToString();
                        Session["Name"] = obj.Name.ToString();

                        if (obj.Roles == "Admin")
                            return RedirectToAction("Index", "Adminroles");
                        if (obj.Roles == "Employee")
                            return RedirectToAction("Index", "Employeeroles");
                        if (obj.Roles == "Librarian")
                            return RedirectToAction("Index", "Librarianroles");

                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid login attempt");
                        return View(objUser);

                    }

                }

            }
            return View(objUser);

        }

        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            Session.RemoveAll();
            Session.Abandon(); // it will clear the session at the end of request

            return RedirectToAction("index", "Login");
        }

        //public ActionResult Contact()
        //{
        //    ViewBag.Message = "your contact page.";

        //  return View();
        //}
        ////post
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> Contact(Email model)
        //{
        //    if(ModelState.IsValid)
        //    {
        //        var body = "<p>Email From:{0} ({1})</p><p>Message:</p><p>{2}</p>";
        //        var message = new MailMessage();
        //        message.To.Add(new MailAddress(model.ToMail));
        //        message.Form = new MailAddress("indu.k@capgemini.com");
        //        message.Subject = "your email subject";

        //    }
        //}
    }
}
    
